
//                          @RETRO  GAMER   SNAKE            

// Librería Functional Light

let { append, cons, first, isEmpty, isList, length, rest, map, forEach } = functionalLight;

// Snake Inicial

let snakeInicial = [{ x: 8, y: 3 }, { x: 9, y: 3 }, { x: 10, y: 3 }]

// Score Inicial

let scoreBasic = 0;

// Mundo inicial

let Mundo = {}
let time;

// Canvas

const WIDTH = 930;
const HEIGHT = 930;
const SIZE = 30;

// Tamaño serpiente

const dx = 30;
const dy = 30;

// Mapa de pixeles

MAPA =            [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1, 1, 1, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]];

//Imagenes

let FOTO = null;
let OVER;
let FOOD = null;
let TUBO;
let CLOUDS;
let BGD;
let DOG;
let DUCK;
let pato1X = 300;
let DUCK2;
let pato2X = 80;
let pato2Y = 300;
let DUCK3;
let pato3X = 750;
let pato3Y = 350;
let DUCK4;
let pato4Y = 650;

// fuente

let fontGta;

//Musica

var song;
var loose;
var QUACK;

//Precargas de datos

function preload() {
  song = loadSound("music/duck.mp3");
  loose = loadSound("music/gameOverD.mp3");
  fontGta = loadFont("font/Pixellari.ttf");
  QUACK = loadSound("music/quack.mp3");

  //Carga las imagenes
  OVER = loadImage("img/Duck/Duck_Hunt.png");
  FOOD = loadImage("img/pacman/Manzana.png");
  BGD = loadImage("img/Duck/BGduck.png");
  DOG = loadImage("img/Duck/DOG2.png");
  DUCK = loadImage("img/Duck/duck.png");
  DUCK2 = loadImage("img/Duck/duck22.png");
  DUCK3 = loadImage("img/Duck/duck33.png");
  DUCK4 = loadImage("img/Duck/duck44.png");
}


//////////////////////////////////// (  Setup  )


//Config

function setup() {

  // Reproduce la cancion
  
  song.play();
  song.loop();

  // Crea el lienzo
  
  createCanvas(WIDTH, HEIGHT);
  background(0);

  // Velocidad snake
  
  setSpeed();

  //Modos de texto
   
  textFont(fontGta);
  stroke(0);
  fill(0);
  textSize(20);
  textStyle(BOLD);

  //Inicializa el mundo
  
  Mundo = { time: 0, snake: snakeInicial, dir: { x: 1, y: 0 }, score: scoreBasic, food: [{ x: floor(random(2,29)), y: floor(random(2,29))}] }
}

//////////////////////////////////// (  Draw  )

function drawGame(Mundo) {

  //Genera mapa
  
  push();
  forEach(MAPA, (row, i) => {
    forEach(row, (cell, j) => {
      if (cell == 1) {
        noStroke();
        fill(255);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 0) {
        noStroke();
        fill(60, 188, 252);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
      }
    });
  });
  pop();


  //Agrega Imagenes.

    image(BGD, 30, 400, 870, 500);
    image(DOG, 450, 688, 90, 90);
    image(DUCK, pato1X, 80, 70, 70); 
    pato1X++;
    image(DUCK4, 750, pato4Y, 65, 70);  
    pato4Y--;
    image(DUCK2, pato2X, pato2Y, 70, 70);    
    pato2X++;
    pato2Y--;
    image(DUCK3, pato3X, pato3Y, 60, 65);    
    pato3X--;
    pato3Y--;

  
  // Dibuja la snake.

    push(); 
    drawSnake(Mundo.snake);
    pop();

  // Dibuja la comida.

    push();
    drawFood(Mundo.food);
    pop();

  // Dibuja el score.

    push();
    textSize(30);
    drawScore();
    pop();
  
  // Texto advertencia controles

    push();
    stroke(0);
    fill(random(255), random(255), random(255));
    textSize(25);
    text_invertir();
    pop();
  
  // Implementa el Game over.

    gameOver();

}


//////////////////////////////////// (  Funciones secundarias  )


var arriba = { dir: { y: -1, x: 0 } };
var abajo = { dir: { y: +1, x: 0 } };
var derecha = { dir: { y: 0, x: +1 } };
var izquierda = { dir: { y: 0, x: -1 } };


/**
 * Funcion que invierte la tecla arriba
 * @param  {Object} arriba
 * @returns {Object}
*/

function invetir_tecla_arriba (arriba){
  score_actual = (length(Mundo.snake) - 3);
  new_arriba = arriba;

  if ( score_actual >= 10 && score_actual <= 15 ){
    new_arriba = { dir: { y: +1, x: 0 } }
    return new_arriba;
  } else {
    return new_arriba;
  }
}

/**
 * Funcion que invierte la tecla abajo
 * @param  {Object} abajo
 * @returns {Object}
*/

function invetir_tecla_abajo (abajo){
  score_actual = (length(Mundo.snake) - 3);
  new_abajo = abajo;

  if ( score_actual >= 10 && score_actual <= 15 ){
    new_abajo = { dir: { y: -1, x: 0 } }
    return new_abajo;
  } else {
    return new_abajo;
  }
}

/**
 * Funcion que invierte la tecla izquierda
 * @param  {Object} izquierda
 * @returns {Object}
*/

function invetir_tecla_izquierda(izquierda){
  score_actual = (length(Mundo.snake) - 3);
  new_izquierda = izquierda;

  if ( score_actual >= 10 && score_actual <= 15 ){
    new_izquierda = { dir: { y: 0, x: +1 } };
    return new_izquierda;
  } else {
    return new_izquierda;
  }
}


/**
 * Funcion que invierte la tecla derecha
 * @param  {Object} derecha
 * @returns {Object}
*/

function invetir_tecla_derecha(derecha){
  score_actual = (length(Mundo.snake) - 3);
  new_derecha = derecha;

  if ( score_actual >= 10 && score_actual <= 15 ){
    new_derecha = { dir: { y: 0, x: -1 } }
    return new_derecha;
  } else {
    return new_derecha;
  }
}


// Actualiza el mundo cada vez que se oprime una tecla. Retorna el nuevo stado del mundo.

function onKeyEvent(Mundo, keyCode) {

  if (keyCode == UP_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != -1)) {
    return update(Mundo, invetir_tecla_arriba(arriba) );
  } else if (keyCode == DOWN_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != -1)) {
    return update(Mundo, invetir_tecla_abajo(abajo));
  } else if (keyCode == LEFT_ARROW && (Mundo.dir.x != -1 && Mundo.dir.y != 0)) {
    return update(Mundo, invetir_tecla_izquierda(izquierda));
  } else if (keyCode == RIGHT_ARROW && (Mundo.dir.x != 1 && Mundo.dir.y != 0)) {
    return update(Mundo, invetir_tecla_derecha(derecha));
  } else {
    return update(Mundo, {});
  }
}


/**
 * Funcion que dibuja el puntaje
 * @param  {Number} score
 * @returns {Structure}
*/
function drawScore(score) {
  push();

  if ( collision_food() ) {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60);
  } else {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60);
  }

  pop();
}

/**
 * Funcion que dibuja la advertencia de controles invertidos
 * @param  {void}
 * @returns {String}
*/
function text_invertir(){
    score_actual = (length(Mundo.snake) - 3);
  if ( score_actual >= 10 && score_actual <= 15 ) {
    return text("Ten cuidado con tus controles", 200, 60);
   } else { 
   return console.log("hola");
   }
}


/**
 * Funcion que define la velocidad
 * @param  {Number} value
 * @returns {Function}
*/
function setSpeed(value) {
  frameRate(8);
}


/**
 * Funcion que dibuja el game over
 * @param  {void}
 * @returns {String}
*/
function gameOver() {
  if ( collision_borde() || collision_snake() ) {
    clear();
    createCanvas(WIDTH, HEIGHT);
    background(OVER);
    song.stop();
    loose.play();
    //-----
    push();
    fill(0)
    textSize(80);
    textAlign(CENTER);1.5
    text("Tu puntaje fue: " + (length(Mundo.snake) - 3), WIDTH / 2, HEIGHT / 2);
    pop();
    noLoop();
  }
}



//////////////////////////////////// (  Colisiones  )



/**
 * Funcion que busca un dato dentro de una lista 
 * @param  {Array, Number} list, element
 * @returns {Boolean}
*/

function searchList(list, element) {
  const firstElement = first(list);
  if (isEmpty(list)) {
    return false;
  } else if (firstElement.x == element.x && firstElement.y == element.y) {
    return true;
  } else {
    return searchList((rest(list)), element);
  }
}



/**
 * Funcion de que confirma si colisona o no con la comida. 
 * @param  {void}
 * @returns {Boolean}
*/
function collision_food() {
  var food1 = (first(Mundo.food));
  var snake1 = (first(Mundo.snake));
  if (food1.x == snake1.x && food1.y == snake1.y) {
    return true;
  } else {
    return false;
  }
}



/**
 * Funcion de que confirma si colisona o no con la cola.
 * @param  {Array} snake
 * @returns {Boolean}
*/
const collision_snake = (snake) => {
  const snake1 = first((Mundo.snake));
  const colasnake = rest(Mundo.snake);
  if (searchList(colasnake, snake1) && length(colasnake) > 2) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con un muro.
 * @param  {Array} snake
 * @returns {Boolean}
*/
function collision_borde(snake) {
  var snake1 = (first(Mundo.snake));
  if (snake1.x == 30 || snake1.y == 30) {
    return true;
  } else if (snake1.x == 0 || snake1.y == 0) {
    return true;
  } else {
    return false;
  }
}



//////////////////////////////////// (  Snake  )


// Actualiza la serpiente. Creando una nuevo cabeza y removiendo la cola.

function moveSnake(snake, dir) {
  const head = first(snake);

  if ( collision_food(head) ) {

    return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) + 1));
  }
  return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) - 1));
}


/**
 * Funcion de que dibuja la serpiente en cuadrados de colores.
 * @param  {Array} snake
 * @returns {Array}
*/
function drawSnake(snake) {
  forEach(snake, part => {

    fill(random(255), random(255), random(255));

    rect(part.x * dx, part.y * dy, dx, dy, 5);
  });
}


//////////////////////////////////// (  food  )

/**
 * Funcion que dibuja la comida en forma de imagen 
 * @param  {Array} food
 * @returns {Boolean}
*/
function drawFood(food) {
  forEach(food, part => {
    fill(200, 20, 10);
    image(FOOD, part.x * dx, part.y * dy, dx, dy);  
  });
}


//////////////////////////////////// (  Funciones principales  )


// Actualiza los atributos del objeto y retorna una copia profunda.

function update(data, attribute ) {
  return Object.assign({}, data, attribute);
}


//Implemente esta función si quiere que su programa reaccione a eventos del mouse.

function onMouseEvent(Mundo, event) {
  return update(Mundo, {});
}



// Esto se ejecuta en cada tic del reloj. Con esto se pueden hacer animaciones.

function onTic(Mundo) {
if ( collision_food() ){
  console.log(Mundo.time );
 return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir), 
 food: [{ x: floor(random(2,30)), y: floor(random(2,30))}] , time: Mundo.time + 1 });
} else {
return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir)  });
}

}
//////////////////////////////////// (  End  )

