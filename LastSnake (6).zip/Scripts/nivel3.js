
//                          @RETRO  GAMER   SNAKE            

// Librería Functional Light
let { append, cons, first, isEmpty, isList, length, rest, map, forEach } = functionalLight;


// Snake Inicial
let snakeInicial = [{ x: 8, y: 3 }, { x: 9, y: 3 }, { x: 10, y: 3 }]

// Score Inicial
let scoreBasic = 0;

let moveXG = 80;
let moveYG = 430;
let moveXT = 820;
let moveYT = 750;
let moveXG2 = 600;
let moveYG2 = 800;



// bordes
 const total_bordes_random_x = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,21,22,23,24,25,26,27,28,29,30];
 const total_bordes_random_y = [0,6,7,8,9,10,11,12,16,17,18,19,20,22,23,24,25,26,27,28,29,30];


// bordes individuales
const bordes_x = [1, 2, 3, 4, 5, 6];
const bordes_y = [16];

const bordes_x_2 = [4, 5, 6];
const bordes_y_2 = [20];

const bordes_x_3 = [21, 22, 23, 24, 25, 26, 27, 28, 29];
const bordes_y_3 = [11, 12];

const bordes_x_4 = [21];
const bordes_y_4 = [6, 7, 8, 9, 10];

const bordes_y_5 = [29];
const bordes_x_5 = [1, 2, 3, 4, 5, 6, 7, 9, 9, 10, 11, 12, 13, 14, 15];


const bordes_y_6 = [22, 23, 24, 25, 26, 27, 28];
const bordes_x_6 = [15];

const bordes_x_7 = [25,26,27];
const bordes_y_7  = [29, 28, 27];

const bordes_x_8 = [6]
const bordes_y_8 = [17, 18, 19]


// Mundo inicial
let Mundo = {}

//Canvas
const WIDTH = 930;
const HEIGHT = 930;
const SIZE = 30;

//Tamaño serpiente
const dx = 30;
const dy = 30;

//Mapa de pixeles
MAPA =            [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]];

//Imagenes
let FOTO = null;
let OVER;
let FOOD = null;
let TUBO;
let CLOUDS;
let GHOST;
let GHOST2;


//fuentes
let fontGta;

//Musica
var song;
var loose;


//Precargas de datos
function preload() {
  song = loadSound("music/mario3.mp3");
  loose = loadSound("music/gameover.mp3");
  fontGta = loadFont("font/Pixellari.ttf");
  
   //Carga las imagenes
  OVER = loadImage("img/Otros/loser3.jpg");
  FOOD = loadImage("img/mario/hongito.png");
  TUBO = loadImage("img/mario/tuberia.png");
  LAVA = loadImage("img/mario/brickLava.png");
  LAVITA = loadImage("img/mario/lavita.png");
  TURTLE = loadImage("img/mario/turtle.png");
  GHOST = loadImage("img/mario/Fantasmita.png");
  GHOST2 = loadImage("img/mario/Fantasmita1.png");
}


//////////////////////////////////// (  Setup  )

//Config
function setup() {
  frameRate(10);

  //Reproduce la cancion
  song.play();
  song.loop();

  //Crea el lienzo
  createCanvas(WIDTH, HEIGHT);
  
 //Modos de texto
  textFont(fontGta);
  stroke(0);
  strokeWeight(2);
  fill(255);
  textSize(30);
  textStyle(BOLD);

  //Inicializa el mundo
  Mundo = { time: 0, snake: snakeInicial, dir: { x: 1, y: 0 }, score: scoreBasic, food: [{ x: floor(random(2,30)), y: floor(random(2,30))}] }
}

//////////////////////////////////// (  Draw  )

function drawGame(Mundo) {

  //Genera mapa

  push();
  forEach(MAPA, (row, i) => {
    forEach(row, (cell, j) => {
      if (cell == 1) {
        noStroke();
        fill(200, 0, 0);
        image(LAVA, j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 0) {
        noStroke();
        fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 2) {
        noStroke();
        fill(0);
        image(LAVITA, j * SIZE, i * SIZE, SIZE, SIZE)
      } if (cell == 3) {
        noStroke();
        fill(0, 0, 50);
        image(TURTLE, j * SIZE, i * SIZE, SIZE, SIZE);
      }
    });
  });
  pop();


  //Agrega Imagenes
    image(TUBO, 600, 825, 80, 90);
    image(TURTLE, 750, moveXT, 80, 80);
    image(GHOST, moveXG, moveYG, 60, 60);
    moveYG--
    moveXG++
    image(GHOST2, moveXG2 , moveYG2, 60, 60);
    moveYG2--
    moveXG2--
 

  // Dibuja la snake
   push();
    drawSnake(Mundo.snake);
  pop();


  // Dibuja la comida
    push();
      drawFood(Mundo.food);
    pop();


  // Dibuja el score 
    push();
    drawScore();
    pop();


  // Implementa el Game over
    gameOver();

}



//////////////////////////////////// (  Funciones secundarias  )


/**
 * Funcion que dibuja el puntaje
 * @param  {Number} score
 * @returns {Structure}
*/
function drawScore(score) {
  if (collision_food()) {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60);
  } else {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60);
  }
  pop();
}

/**
 * Funcion que define la velocidad
 * @param  {Number} value
 * @returns {Function}
*/
function setSpeed(value) {
  frameRate(value);
}

/**
 * Funcion que dibuja el game over
 * @param  {void}
 * @returns {String}
*/
function gameOver() {
  if ( collision_borde() || collision_snake() || collision_muro() ) {
    clear();
    //-----
    createCanvas(WIDTH, HEIGHT);
    background(OVER);
    song.stop();
    loose.play();
    //-----
    push();
    fill(255);
    textSize(30);
    textAlign(CENTER);
    text("Tu puntaje fue: " + (length(Mundo.snake) - 3), WIDTH / 2, HEIGHT / 1.5);
    pop();
    //-----
    noLoop();
  }
}


//////////////////////////////////// (  Colisiones  )


/**
 * Funcion que busca un dato dentro de una lista 
 * @param  {Array, Number} list, element
 * @returns {Boolean}
*/
function searchList(list, element) {
  const firstElement = first(list);
  if (isEmpty(list)) {
    return false;
  } else if (firstElement.x == element.x && firstElement.y == element.y) {
    return true;
  } else {
    return searchList((rest(list)), element)
  }
}


/**
 * Funcion que busca un dato dentro de una lista 
 * @param  {Array, Number} list, element
 * @returns {Number}
*/
const searchList_direccion = (list,element) =>{
if (isEmpty(list)){
  return 0;
}else if(first(list)==element){
  return element;
}else {
  return searchList_direccion(rest(list),element);
}
}


/**
 * Funcion de que confirma si colisona o no con la comida. 
 * @param  {void}
 * @returns {Boolean}
*/
function collision_food() {
  var food1 = (first(Mundo.food));
  var snake1 = (first(Mundo.snake));
  if (food1.x == snake1.x && food1.y == snake1.y) {
    return true
  } else {
    return false
  }
}


/**
 * Funcion de que confirma si colisona o no con la cola.
 * @param  {Array} snake
 * @returns {Boolean}
*/
const collision_snake = (snake) => {
  const snake1 = first((Mundo.snake));
  const colasnake = rest(Mundo.snake);
  if (searchList(colasnake, snake1) && length(colasnake) > 2) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con un muro.
 * @param  {Array} snake
 * @returns {Boolean}
*/
function collision_borde(snake) {
  var snake1 = (first(Mundo.snake));
  if (snake1.x == 30 || snake1.y == 30) {
    return true;
  } else if (snake1.x == 0 || snake1.y == 0) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con un muro individual.
 * @param  {Array} snake
 * @returns {Boolean}
*/
function collision_muro(snake) {
  var snake1 = (first(Mundo.snake));

   if (collision_borde(snake) == false)
   {
      if ( 
          searchList_direccion(bordes_x , snake1.x) == snake1.x && searchList_direccion(bordes_y , snake1.y) == snake1.y
          )  
          {
            return true;
          }else if(
            searchList_direccion(bordes_x_2 , snake1.x) == snake1.x && searchList_direccion(bordes_y_2 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }else if(
            searchList_direccion(bordes_x_3 , snake1.x) == snake1.x && searchList_direccion(bordes_y_3 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }else if(
            searchList_direccion(bordes_x_4 , snake1.x) == snake1.x && searchList_direccion(bordes_y_4 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          } else if(
            searchList_direccion(bordes_x_5 , snake1.x) == snake1.x && searchList_direccion(bordes_y_5 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }  else if(
            searchList_direccion(bordes_x_6 , snake1.x) == snake1.x && searchList_direccion(bordes_y_6 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }   else if(
            searchList_direccion(bordes_x_7 , snake1.x) == snake1.x && searchList_direccion(bordes_y_7 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }   else if(
            searchList_direccion(bordes_x_8 , snake1.x) == snake1.x && searchList_direccion(bordes_y_8 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }

          else 
          {
            return false;
          }
   }
}


/**
 * Funcion de que confirma si colisona o no con un muro individual.
 * @param  {Array} snake
 * @returns {Boolean}
*/
const searchList_direccion_food = (list,element) =>{
if (isEmpty(list)){
  return false;
}else if (first(list) == element){
  return true;
}else{
return searchList_direccion_food(rest(list),element);
}

}


/**
 * Funcion que imprime la comida de forma aleatoria
 * @param  {Number, Number} new_x, new_y
 * @returns {Structure}
*/
function comida_pos (new_x = floor(random(1,29)) , new_y = floor(random(1,29)) ){

  var comida_position = first(Mundo.food);
  var newStructure = [{x:new_x, y:new_y}];

  if(searchList_direccion_food(total_bordes_random_x , new_x) == false && searchList_direccion_food(total_bordes_random_y , new_y) == false ){
    if(comida_position.y != new_y && comida_position.x != new_x ){
      return newStructure;
    }else {
      return comida_pos( new_x = floor(random(1,29)) , new_y = floor(random(1,29)));
    }
 }else{
   return comida_pos( new_x = floor(random(1,29)) , new_y = floor(random(1,29)));
 }

}
  

//////////////////////////////////// (  Snake  )


// Actualiza la serpiente. Creando una nuevo cabeza y removiendo la cola
 
function moveSnake(snake, dir) {
  const head = first(snake);

  if (collision_food(head)) {
    return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) + 1));
  }
  return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) - 1));
}


/**
 * Funcion de que dibuja la serpiente en cuadrados de colores.
 * @param  {Array} snake
 * @returns {Array}
*/
function drawSnake(snake) {
  forEach(snake, part => {
    fill(random(255), random(255), random(255));
    rect(part.x * dx, part.y * dy, dx, dy, 5);
  });
}


//////////////////////////////////// (  food  )

/**
 * Funcion que dibuja la comida.
 * @param  {Array} food
 * @returns {Boolean}
*/
function drawFood(food) {
  forEach(food, part => {
    fill(200, 20, 10);
    //rect(part.x * dx, part.y *dy, dx, dy);
    image(FOOD, part.x * dx, part.y * dy, dx, dy);
  });
}


//////////////////////////////////// (  Funciones principales  )


// Actualiza los atributos del objeto y retorna una copia profunda

function update(data, attribute ) {
  return Object.assign({}, data, attribute);
}


//Implemente esta función si quiere que su programa reaccione a eventos del mouse

function onMouseEvent(Mundo, event) {
  return update(Mundo, {});
}


// Actualiza el mundo cada vez que se oprime una tecla. Retorna el nuevo stado del mundo

function onKeyEvent(Mundo, keyCode) {
  if (keyCode == UP_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != 1)) {
    return update(Mundo, { dir: { y: -1, x: 0 } });
  } else if (keyCode == DOWN_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != -1)) {
    return update(Mundo, { dir: { y: 1, x: 0 } });
  } else if (keyCode == LEFT_ARROW && (Mundo.dir.x != 1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: -1 } });
  } else if (keyCode == RIGHT_ARROW && (Mundo.dir.x != -1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: 1 } });
  } else {
    return update(Mundo, {});
  }
}

// Esto se ejecuta en cada tic del reloj. Con esto se pueden hacer animaciones

function onTic(Mundo) {
if(collision_food()){
 return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir), 
 food: comida_pos() });
}else{
return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir)  });
}
}

//////////////////////////////////// (  End  )
