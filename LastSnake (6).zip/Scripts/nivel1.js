
//                          @RETRO  GAMER   SNAKE            

// Librería Functional Light.
let { append, cons, first, isEmpty, isList, length, rest, map, forEach } = functionalLight;


// Snake Inicial.
let snakeInicial = [{ x: 8, y: 3 }, { x: 9, y: 3 }, { x: 10, y: 3 }]

// Score Inicial.
let scoreBasic = 0;
let score = 0;


// Mundo inicial.
let Mundo = {};


//Canvas.
const WIDTH = 400;
const HEIGHT = 400;
const SIZE = 40;


//Tamaño serpiente.
const dx = 20;
const dy = 20;


//Mapa de pixeles.
const MAPA = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
];


//Imagenes.
let FOTO = null;
let OVER;
let FOOD = null;
let TUBO;
let CLOUDS;


//fuente GTA.
let fontGta;

//Musica.
var song;
var loose;

//Precargas de datos.

function preload() {

  song = loadSound("music/mario1.mp3");
  loose = loadSound("music/gameover.mp3");
  fontGta = loadFont("font/Pixellari.ttf");
  fontMario = loadFont("font/mario.ttf");
  
//Carga las imagenes.
  FOTO = loadImage('img/mario/Ground_mario.png');
  OVER = loadImage("img/mario/gameOverM.jpg");
  FOOD = loadImage("img/mario/hongito.png");
  TUBO = loadImage("img/mario/tuberia.png");
  CLOUDS = loadImage("img/mario/clouds.png");
}

//////////////////////////////////// (  Setup  )


//Config.

function setup() {

  //Reproduce la cancion.

  song.play();
  song.loop();

  //Crea el lienzo.

  createCanvas(WIDTH, HEIGHT);
  
  
  //Velocidad snake.

  setSpeed();


  //Modos de texto.

  textFont(fontGta);
  stroke(0);
  strokeWeight(2);
  fill(255);
  textSize(20);
  textStyle(BOLD);


  //Inicializa el mundo.

  Mundo = { time: 0, snake: snakeInicial, dir: { x: 1, y: 0 }, score: scoreBasic, food: [{ x: 13, y: 13}] }

}

//////////////////////////////////// (  Draw  )


//Funcion que dibuja el mundo.

function drawGame(Mundo) {

  //Genera mapa.

  push();
  forEach(MAPA, (row, i) => {
    forEach(row, (cell, j) => {
      if (cell == 1) {
        noStroke();
        fill(200, 0, 0);
        image(FOTO, j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 0) {
        noStroke();
        fill(93, 147, 253);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 2) {
        noStroke();
        fill(0, 0, 50);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
        fill(15, 200, 50);
        ellipse(j * SIZE + SIZE / 2, i * SIZE + SIZE / 2, SIZE / 3, SIZE / 3);
      }
    });
  });
  pop();


  //Agrega Imagenes
    image(TUBO, 50, 295, 80, 80);
    image(CLOUDS, 150, 80, 120, 70)


  // Dibuja la snake
      push()
        drawSnake(Mundo.snake);
      pop()


  // Dibuja la comida
    drawFood(Mundo.food);


  // Dibuja el score 
    //push();
    drawScore();
    //pop();


  // Implementa el Game over
    gameOver();

}


//////////////////////////////////// (  Funciones secundarias  )


/**
 * Funcion que dibuja el puntaje
 * @param  {Number} score
 * @returns {Structure}
*/
function drawScore(score) {
    if (collision_food()) {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60)
  } else {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60)
  }
}

/**
 * Funcion que define la velocidad
 * @param  {Number} value
 * @returns {Function}
*/
function setSpeed(value) {
  frameRate(8);
}

/**
 * Funcion que dibuja el game over
 * @param  {void}
 * @returns {String}
*/
function gameOver() {

  if (collision_borde() || collision_snake()) {
    clear();
    //-----
    createCanvas(WIDTH, HEIGHT);
    background(OVER)
    //-----
    song.stop()
    loose.play();
    //-----
    push();
    fill(255)
    textSize(22);
    textAlign(CENTER);
    text("Tu puntaje fue: " + (length(Mundo.snake) - 3), WIDTH / 2, HEIGHT / 1.4);
    pop();
    //-----
    noLoop();
  }
}



//////////////////////////////////// (  Colisiones  )


/**
 * Funcion que busca un dato dentro de una lista 
 * @param  {Array, Number} list, element
 * @returns {Boolean}
*/
function searchList(list, element) {
  const firstElement = first(list);
  if (isEmpty(list)) {
    return false;
  } else if (firstElement.x == element.x && firstElement.y == element.y) {
    return true;
  } else {
    return searchList((rest(list)), element)
  }
}


/**
 * Funcion de que confirma si colisona o no con la comida. 
 * @param  {void}
 * @returns {Boolean}
*/
function collision_food() {
  var food1 = (first(Mundo.food));
  var snake1 = (first(Mundo.snake));
  if (food1.x == snake1.x && food1.y == snake1.y) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con la cola.
 * @param  {Array} snake
 * @returns {Boolean}
*/
const collision_snake = (snake) => {
  const snake1 = first((Mundo.snake));
  const colasnake = rest(Mundo.snake)
  if (searchList(colasnake, snake1) && length(colasnake) > 2) {
    return true;
  } else {
    return false;
  }
}

/**
 * Funcion de que confirma si colisona o no con un muro.
 * @param  {Array} snake
 * @returns {Boolean}
*/
function collision_borde(snake) {
  var snake1 = (first(Mundo.snake))
  if (snake1.x == 18 || snake1.y == 18) {
    return true;
  } else if (snake1.x == 1 || snake1.y == 1) {
    return true;
  } else {
    return false;
  }
}



//////////////////////////////////// (  Snake  )


// Funcion que actualiza la serpiente. Creando una nueva cabeza y removiendo la cola.
 
function moveSnake(snake, dir) {
  const head = first(snake);

  if (collision_food(head)) {
    return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) + 1));
  }
  return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) - 1));
}



/**
 * Funcion de que dibuja la serpiente en cuadrados de colores.
 * @param  {Array} snake
 * @returns {Array}
*/
function drawSnake(snake) {
  forEach(snake, part => {
    fill(random(255), random(255), random(255));
    rect(part.x * dx, part.y * dy, dx, dy, 5);
  });
}


//////////////////////////////////// (  food  )

/**
 * Funcion que dibuja la comida en forma de imagen 
 * @param  {Array} food
 * @returns {Boolean}
*/
function drawFood(food) {
  forEach(food, part => {
    image(FOOD, part.x * dx, part.y * dy, dx, dy)   
  });
}



//////////////////////////////////// (  Funciones principales  )


// Actualiza los atributos del objeto y retorna una copia profunda

function update(data, attribute ) {
  return Object.assign({}, data, attribute);
}



//Implemente esta función si quiere que su programa reaccione a eventos del mouse

function onMouseEvent(Mundo, event) {
  return update(Mundo, {});
}


// Actualiza el mundo cada vez que se oprime una tecla. Retorna el nuevo estado del mundo

function onKeyEvent(Mundo, keyCode) {
  if (keyCode == UP_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != 1)) {
    return update(Mundo, { dir: { y: -1, x: 0 } });
  } else if (keyCode == DOWN_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != -1)) {
    return update(Mundo, { dir: { y: 1, x: 0 } });
  } else if (keyCode == LEFT_ARROW && (Mundo.dir.x != 1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: -1 } });
  } else if (keyCode == RIGHT_ARROW && (Mundo.dir.x != -1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: 1 } });
  } else {
    return update(Mundo, {});
  }
}

// Funcion para que se ejecute en cada tic del reloj. Con esto se pueden hacer animaciones

function onTic(Mundo) {
if(collision_food()){
 return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir), 
 food: [{ x: floor(random(2,17)), y: floor(random(4,17)) }], score: drawScore(score) });
}else{
return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir)  });
}

}


//////////////////////////////////// (  End  )

