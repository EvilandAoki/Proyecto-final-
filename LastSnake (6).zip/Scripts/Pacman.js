
//                          @RETRO  GAMER   SNAKE            

// Librería Functional Light
let { append, cons, first, isEmpty, isList, length, rest, map, forEach } = functionalLight;


// Snake Inicial
let snakeInicial = [{ x: 8, y: 3 }, { x: 9, y: 3 }, { x: 10, y: 3 }]

// Score Inicial
let scoreBasic = 0;

// bordes
const bordes_x = [];
const bordes_y = [];


// Mundo inicial
let Mundo = {}

//Canvas
const WIDTH = 930;
const HEIGHT = 930;
const SIZE = 30;

//Tamaño serpiente
const dx = 30;
const dy = 30;

//Mapa de pixeles
MAPA =            [[5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1],
                  [1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
                  [1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1],
                  [5, 5, 5, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 5, 5, 5],
                  [5, 5, 5, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 5, 5, 5],
                  [5, 5, 5, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 5, 5, 5],
                  [1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1],
                  [5, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5],
                  [5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 5],
                  [1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 2, 0, 0, 3, 0, 0, 6, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1],
                  [5, 5, 5, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 5, 5, 5],
                  [5, 5, 5, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 3, 1, 5, 5, 5],
                  [5, 5, 5, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 5, 5, 5],
                  [1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
                  [5, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 5],
                  [1, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 1],
                  [5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5]];

//Imagenes
let FOTO = null;
let OVER;
let FOOD = null;
let TUBO;
let CLOUDS;
let CHERRY;
let GAZUL;
let GAROJO;
let GAROSA;
let GANARANJA;


//fuente GTA
let fontGta;


//Musica
var song;
var loose;


//Precargas de datos
function preload() {
  song = loadSound("music/Pacman.mp3");
  loose = loadSound("music/PacmanF.mp3");
  fontGta = loadFont("font/Pixellari.ttf");

  //Carga las imagenes
  OVER = loadImage("img/pacman/gameOverPacman.png");
  CHERRY = loadImage("img/pacman/Cerezas.png");
  GAZUL = loadImage("img/mario/azulC.png");
  GAROJO = loadImage("img/pacman/rojo.png");
  GAROSA = loadImage("img/pacman/rosa.png");
  GANARANJA = loadImage("img/pacman/orange.png");
}


//////////////////////////////////// (  Setup  )

//Config
function setup() {

  //Reproduce la cancion
  song.play();
  song.loop();


  //Crea el lienzo
  createCanvas(WIDTH, HEIGHT);
  

  //Velocidad snake
  setSpeed(13);


  //Modos de texto
  textFont(fontGta);
  stroke(0);
  strokeWeight(2);
  fill(255);
  textSize(30);
  textStyle(BOLD);


  //Inicializa el mundo
  Mundo = { time: 0, snake: snakeInicial, dir: { x: 1, y: 0 }, score: scoreBasic, food: [{ x: floor(random(2,30)), y: floor(random(2,30))}] }
}

//////////////////////////////////// (  Draw  )

function drawGame(Mundo) {

  //Genera mapa
  push();
  forEach(MAPA, (row, i) => {
    forEach(row, (cell, j) => {
      
      if (cell == 1) {
        stroke(0);
        fill(30, 27, 213);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
      } 
      if (cell == 0) {
        noStroke();
        fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
        fill(246, 170, 178);
        ellipse(j * SIZE + SIZE / 2, i * SIZE + SIZE / 2, SIZE / 3, SIZE / 3);
      } 
      if (cell == 2) {
        fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
        noStroke();
        fill(0, 0, 50);
        image(GAZUL, j * SIZE, i * SIZE, SIZE, SIZE);
      } 
      if (cell == 3) {
        fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
        noStroke();
        fill(0, 0, 50);
        image(GAROJO, j * SIZE, i * SIZE, SIZE, SIZE);
      } 
      if (cell == 4) {
        fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
        noStroke();
        fill(0, 0, 50);
        image(GAROSA, j * SIZE, i * SIZE, SIZE, SIZE);
      }
       if (cell == 5) {
        noStroke();
        fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
      } 
      if (cell == 6) {
        fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
        noStroke();
        fill(0, 0, 50);
        image(GANARANJA, j * SIZE, i * SIZE, SIZE, SIZE);
      }
    });
  });
  pop();

 
  // Dibuja la snake
    push();
    drawSnake(Mundo.snake);
    pop();

  // Dibuja la comida
    push();
    drawFood(Mundo.food);
    pop();


  // Dibuja el score 
    push();
    drawScore();
    pop();

  // Implementa el Game over
    gameOver();

}


//////////////////////////////////// (  Funciones secundarias  )


/**
 * Funcion que dibuja el puntaje
 * @param  {Number} score
 * @returns {Structure}
*/
function drawScore(score) {
  push();
  fill(255,255,0);
  stroke(0);
  //----
  if (collision_food()) {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60);
  } else {
    return text("Score: " + (length(Mundo.snake) - 3), 47, 60);
  }
  pop();
}

/**
 * Funcion que define la velocidad
 * @param  {Number} value
 * @returns {Function}
*/
function setSpeed(value) {
  frameRate(value);
}

/**
 * Funcion que dibuja el game over
 * @param  {void}
 * @returns {String}
*/
function gameOver() {
  if (collision_borde() || collision_snake()) {
    clear();
    createCanvas(WIDTH, HEIGHT);
    push();
    fill(0);
    rect(0,0,WIDTH,HEIGHT);
    pop();
    background(OVER);
    song.stop();
    loose.play();
    //-----
    push();
    fill(255);
    textSize(30);
    textAlign(CENTER);
    text("Tu puntaje fue: " + (length(Mundo.snake) - 3), WIDTH / 2, HEIGHT / 1.3);
    pop();
    noLoop();
  }
}


//////////////////////////////////// (  Colisiones  )


/**
 * Funcion que busca un dato dentro de una lista 
 * @param  {Array, Number} list, element
 * @returns {Boolean}
*/
function searchList(list, element) {
  const firstElement = first(list);
  if (isEmpty(list)) {
    return false;
  } else if (firstElement.x == element.x && firstElement.y == element.y) {
    return true;
  } else {
    return searchList((rest(list)), element)
  }
}


/**
 * Funcion de que confirma si colisona o no con la comida. 
 * @param  {void}
 * @returns {Boolean}
*/
function collision_food() {
  var food1 = (first(Mundo.food));
  var snake1 = (first(Mundo.snake));
  if (food1.x == snake1.x && food1.y == snake1.y) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con la cola.
 * @param  {Array} snake
 * @returns {Boolean}
*/
const collision_snake = (snake) => {
  const snake1 = first((Mundo.snake));
  const colasnake = rest(Mundo.snake);
  if (searchList(colasnake, snake1) && length(colasnake) > 2) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con un muro.
 * @param  {Array} snake
 * @returns {Boolean}
*/
function collision_borde(snake) {
  var snake1 = (first(Mundo.snake))
  if (snake1.x == 30 || snake1.y == 30) {
    return true;
  } else if (snake1.x == 0 || snake1.y == 0) {
    return true;
  } else {
    return false;
  }
}


//////////////////////////////////// (  Snake  )


// Actualiza la serpiente. Creando una nuevo cabeza y removiendo la cola
 
function moveSnake(snake, dir) {
  const head = first(snake);

  if (collision_food(head)) {
    return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) + 1));
  }
  return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) - 1));
}

/**
 * Funcion de que dibuja la serpiente en cuadrados de colores.
 * @param  {Array} snake
 * @returns {Array}
*/
function drawSnake(snake) {
  forEach(snake, part => {
    fill(255, 255, 0);
    rect(part.x * dx, part.y * dy, dx, dy, 5);
  });
}

//////////////////////////////////// (  food  )


/**
 * Funcion que dibuja la comida.
 * @param  {Array} food
 * @returns {Boolean}
*/
function drawFood(food) {
  forEach(food, part => {
    noStroke();
    fill(200, 20, 10);
    //rect(part.x * dx, part.y *dy, dx, dy);
    image(CHERRY, part.x * dx, part.y * dy, dx, dy)   
  });
}

////////////////////////////////////// (  Funciones principales  )


// Actualiza los atributos del objeto y retorna una copia profunda

function update(data, attribute ) {
  return Object.assign({}, data, attribute);
}


//Implemente esta función si quiere que su programa reaccione a eventos del mouse

function onMouseEvent(Mundo, event) {
  return update(Mundo, {});
}


// Actualiza el mundo cada vez que se oprime una tecla. Retorna el nuevo stado del mundo

function onKeyEvent(Mundo, keyCode) {
  if (keyCode == UP_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != 1)) {
    return update(Mundo, { dir: { y: -1, x: 0 } });
  } else if (keyCode == DOWN_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != -1)) {
    return update(Mundo, { dir: { y: 1, x: 0 } });
  } else if (keyCode == LEFT_ARROW && (Mundo.dir.x != 1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: -1 } });
  } else if (keyCode == RIGHT_ARROW && (Mundo.dir.x != -1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: 1 } });
  } else {
    return update(Mundo, {});
  }
}


// Esto se ejecuta en cada tic del reloj. Con esto se pueden hacer animaciones

function onTic(Mundo) {
if(collision_food()){
 return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir), 
 food: [{ x: floor(random(2,30)), y: floor(random(2,30))}], time: Mundo.time + 1 });
}else{
return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir)  });
}

}

//////////////////////////////////// (  End  )



