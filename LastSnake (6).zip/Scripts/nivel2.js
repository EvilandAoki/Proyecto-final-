
//                          @RETRO  GAMER   SNAKE            

// Librería Functional Light.
let { append, cons, first, isEmpty, isList, length, rest, map, forEach } = functionalLight;


// Snake Inicial.
let snakeInicial = [{ x: 8, y: 3 }, { x: 9, y: 3 }, { x: 10, y: 3 }]

// Score Inicial.
let scoreBasic = 0;

// bordes de muros
const bordes_x = [4,5,6,7,8,9];
const bordes_y = [17];

const bordes_x_2 = [7,8,9,10,11];
const bordes_y_2 = [6];

const bordes_x_3 = [21, 22];
const bordes_y_3 = [1, 2, 3, 4, 5, 6, 7];

const bordes_x_4 = [4, 5, 6, 7];
const bordes_y_4 = [1];

const bordes_x_5 = [15, 16];
const bordes_y_5 = [21, 22, 23, 24, 25, 26, 27, 28, 29];

const bordes_x_6 = [17, 18, 19, 20, 21];
const bordes_y_6 = [21, 22];

const total_bordes_random_x = [0,4,5,6,7,8,9,10,11,15,16,17,18,19,20,21,22,30];

const total_bordes_random_y = [0,1,2,3,4,5,6,7,17,21,22,23,24,25,26,27,28,29,30];


// Mundo inicial
let Mundo = {}


// Canvas
const WIDTH = 930;
const HEIGHT = 930;
const SIZE = 30;


//T amaño serpiente
const dx = 30;
const dy = 30;


// Mapa de pixeles
MAPA =            [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                  [1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 4, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]];


//Imagenes.
let FOTO = null;
let OVER;
let FOOD = null;
let TUBO;
let CLOUDS;


//Fuentes.
let fontGta;
let fontMario;


//Musica.
var song;
var loose;


//Precargas de datos.

function preload() {
  song = loadSound("music/mario2.mp3");
  loose = loadSound("music/gameover.mp3");
  fontGta = loadFont("font/Pixellari.ttf");
  fontMario = loadFont("font/mario.ttf");

 //Carga las imagenes
  FOTO = loadImage('img/mario/Ground_mario.png');
  OVER = loadImage("img/mario/loser.jpg");
  FOOD = loadImage("img/mario/hongoVerde.png");
  TUBO = loadImage("img/mario/tuberia.png");
  WATERB = loadImage("img/mario/waterBrick.jpg");
  FISH = loadImage("img/mario/fish.jpg");
  OCTO = loadImage("img/mario/octopus.png");
  ALGA = loadImage("img/mario/alga.jpg");
}


//////////////////////////////////// (  Setup  )


//Config

function setup() {

  //Reproduce la cancion.
  song.play();
  song.loop();

  //Crea el lienzo.
  createCanvas(WIDTH, HEIGHT);
  

  //Velocidad snake.
  setSpeed();

  
  //Modos de texto.
  textFont(fontGta);
  stroke(0);
  strokeWeight(2);
  fill(255);
  textSize(20);
  textStyle(BOLD);


  //Inicializa el mundo
  Mundo = { time: 0, snake: snakeInicial, dir: { x: 1, y: 0 }, score: scoreBasic, food: [{x:13 , y:12 }]}

}

//////////////////////////////////// (  Draw  )

function drawGame(Mundo) {

  //Genera nuestro mapa.
  push();
  forEach(MAPA, (row, i) => {
    forEach(row, (cell, j) => {
      if (cell == 1) {
        noStroke();
        fill(200, 0, 0);
        image(WATERB, j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 0) {
        noStroke();
        fill(21, 64, 242);
        //fill(0);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 2) {
        noStroke();
        fill(0);
        image(ALGA, j * SIZE, i * SIZE, SIZE, SIZE)
      } if (cell == 3) {
        noStroke();
        fill(21, 64, 242);
        rect(j * SIZE, i * SIZE, SIZE, SIZE);
        fill(0, 0, 50);
        image(OCTO, j * SIZE, i * SIZE, SIZE, SIZE);
      } if (cell == 4) {
        noStroke();
        fill(0, 0, 50);
        image(FISH, j * SIZE, i * SIZE, SIZE, SIZE);
      }
    });
  });
  pop();


  //Agrega Imagenes.
    image(TUBO, 600, 825, 80, 90);


  // Dibuja la snake.
    push();
    drawSnake(Mundo.snake);
    pop();

    
  // Dibuja la comida.
    push();
    drawFood(Mundo.food);
    pop();


  // Comida aleatoria
    

  // Dibuja el score 
    push();
    drawScore();
    pop();


  // Implementa el Game over
    gameOver();


  //colision borde
   collision_muro();
 
}


//////////////////////////////////// (  Funciones secundarias  )

/**
 * Funcion que dibuja el puntaje
 * @param  {Number} score
 * @returns {Structure}
*/
function drawScore(score) {
  push();
  strokeWeight(2);
  stroke(0);
  fill("white");
  //----
  if (collision_food()) {
    textFont('fontMario', 30);
    return text("Score: " + (length(Mundo.snake) - 3), 40, 60);
  } else {
    return text("Score: " + (length(Mundo.snake) - 3), 40, 60);
  }
  pop();
}

/**
 * Funcion que define la velocidad
 * @param  {Number} value
 * @returns {Function}
*/
function setSpeed(value) {
  frameRate(10);
}

/**
 * Funcion que permite seleccionar la velocidad de la serpiente
 * @param  {void}
 * @returns {Function}
*/
function more_speed(){
  score_actual = Mundo.score;

  if ( score_actual > 10 )
  {
    return setSpeed(20);
  } if ( score_actual > 20 ) 
    {
    return setSpeed(40);
    }

}

////////////////////////////////// (  Colisiones  )


/**
 * Funcion que busca un dato dentro de una lista 
 * @param  {Array, Number} list, element
 * @returns {Boolean}
*/
function searchList(list, element) {
  const firstElement = first(list);
  if (isEmpty(list)) {
    return false;
  } else if (firstElement.x == element.x && firstElement.y == element.y) {
    return true;
  } else {
    return searchList((rest(list)), element);
  }
}

/**
 * Funcion que busca en una direccion en particular con un dato y una lista 
 * @param  {Array, Number} list, element
 * @returns {Number}
*/
const searchList_direccion = (list,element) =>{
if (isEmpty(list)){
  return 0;
} else if ( first(list)==element ){
  return element;
} else {
  return searchList_direccion(rest(list),element);
}
}


/**
 * Funcion de que confirma si colisona o no con la comida. 
 * @param  {void}
 * @returns {Boolean}
*/
function collision_food() {
  var food1 = (first(Mundo.food));
  var snake1 = (first(Mundo.snake));
  if (food1.x == snake1.x && food1.y == snake1.y) {
    return true;
  } else {
    return false;
  }
}



/**
 * Funcion de que confirma si colisona o no con la cola.
 * @param  {Array} snake
 * @returns {Boolean}
*/
const collision_snake = (snake) => {
  const snake1 = first((Mundo.snake));
  const colasnake = rest(Mundo.snake)
  if (searchList(colasnake, snake1) && length(colasnake) > 2) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con un muro.
 * @param  {Array} snake
 * @returns {Boolean}
*/
function collision_borde(snake) {
  var snake1 = (first(Mundo.snake));
  if ( snake1.x == 30 || snake1.y == 30 ) {
    return true;
  } else if (snake1.x == 0 || snake1.y == 0) {
    return true;
  } else {
    return false;
  }
}


/**
 * Funcion de que confirma si colisona o no con un muro individual.
 * @param  {Array} snake
 * @returns {Boolean}
*/
function collision_muro(snake) {
  var snake1 = (first(Mundo.snake));

   if (collision_borde(snake) == false)
   {
      if ( 
          searchList_direccion(bordes_x , snake1.x) == snake1.x && searchList_direccion(bordes_y , snake1.y) == snake1.y
          )  
          {
            return true;
          }else if(
            searchList_direccion(bordes_x_2 , snake1.x) == snake1.x && searchList_direccion(bordes_y_2 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }else if(
            searchList_direccion(bordes_x_3 , snake1.x) == snake1.x && searchList_direccion(bordes_y_3 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }else if(
            searchList_direccion(bordes_x_4 , snake1.x) == snake1.x && searchList_direccion(bordes_y_4 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          } else if(
            searchList_direccion(bordes_x_5 , snake1.x) == snake1.x && searchList_direccion(bordes_y_5 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }  else if(
            searchList_direccion(bordes_x_6 , snake1.x) == snake1.x && searchList_direccion(bordes_y_6 , snake1.y) == snake1.y
          ) 
          
          {
            return true;
          }

          else 
          {
            return false;
          }
    } 
}


/**
 * Funcion que busca la direccion de la comida
 * @param  {Array, Number} list, element
 * @returns {Boolean}
*/
const searchList_direccion_food = (list,element) =>{
if (isEmpty(list)){
  return false;
}else if ( first(list) == element ){
  return true;
}else{
return searchList_direccion_food(rest(list),element);
}

}

/**
 * Funcion que imprime la comida de forma aleatoria
 * @param  {Number, Number} new_x, new_y
 * @returns {Structure}
*/
function comida_pos (new_x = floor(random(1,29)) , new_y = floor(random(1,29)) ){
  
  var comida_position = first(Mundo.food);
  var newStructure = [{x:new_x, y:new_y}];

  if ( searchList_direccion_food(total_bordes_random_x , new_x ) == false && searchList_direccion_food(total_bordes_random_y , new_y) == false ){
    if ( comida_position.y != new_y && comida_position.x != new_x ) {
      return newStructure;
    } else {
      return comida_pos( new_x = floor(random(1,29)) , new_y = floor(random(1,29)));
    }
 } else {
   return comida_pos( new_x = floor(random(1,29)) , new_y = floor(random(1,29)));
 }

}


/**
 * Funcion que dibuja el game over
 * @param  {void}
 * @returns {String}
*/
function gameOver() {
  if ( collision_borde() || collision_snake() || collision_muro() ) {
    clear();
    //-----
    createCanvas(WIDTH, HEIGHT);
    background(OVER);
    song.stop();
    loose.play();
    //-----
    push();
    fill(255);
    textSize(30);
    textAlign(CENTER);
    text("Tu puntaje fue: " + (length(Mundo.snake) - 3), WIDTH / 2, HEIGHT / 1.5);
    pop();
    //-----    
    noLoop();
  }
}


//////////////////////////////////// (  Snake  )


// Actualiza la serpiente. Creando una nuevo cabeza y removiendo la cola
 
function moveSnake(snake, dir) {
  const head = first(snake);

  if ( collision_food(head) ) {
    return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) + 1));
  }
  return cons({ x: head.x + dir.x, y: head.y + dir.y }, snake.slice(0, length(snake) - 1));
}


/**
 * Funcion de que dibuja la serpiente en cuadrados de colores.
 * @param  {Array} snake
 * @returns {Array}
*/
function drawSnake(snake) {
  forEach(snake, part => {
    fill(random(255), random(255), random(255));
    rect(part.x * dx, part.y * dy, dx, dy, 5);
  });
}


//////////////////////////////////// (  food  )

/**
 * Funcion que dibuja la comida.
 * @param  {Array} food
 * @returns {Boolean}
*/
function drawFood(food) {
  forEach(food, part => {
    fill(200, 20, 10);
    image(FOOD, part.x * dx, part.y * dy, dx, dy);
  });
}


//////////////////////////////////// (  Funciones principales  )


// Actualiza los atributos del objeto y retorna una copia profunda

function update(data, attribute ) {
  return Object.assign({}, data, attribute);
}



//Implemente esta función si quiere que su programa reaccione a eventos del mouse

function onMouseEvent(Mundo, event) {
  return update(Mundo, {});
}

// Actualiza el mundo cada vez que se oprime una tecla. Retorna el nuevo stado del mundo

function onKeyEvent(Mundo, keyCode) {
  if (keyCode == UP_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != 1)) {
    return update(Mundo, { dir: { y: -1, x: 0 } });
  } else if (keyCode == DOWN_ARROW && (Mundo.dir.x != 0 && Mundo.dir.y != -1)) {
    return update(Mundo, { dir: { y: 1, x: 0 } });
  } else if (keyCode == LEFT_ARROW && (Mundo.dir.x != 1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: -1 } });
  } else if (keyCode == RIGHT_ARROW && (Mundo.dir.x != -1 && Mundo.dir.y != 0)) {
    return update(Mundo, { dir: { y: 0, x: 1 } });
  } else {
    return update(Mundo, {});
  }
}

// Esto se ejecuta en cada tic del reloj. Con esto se pueden hacer animaciones

function onTic(Mundo) {
if(collision_food()){
 return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir), 
 food:comida_pos() });
}else{
return update(Mundo, { snake: moveSnake(Mundo.snake, Mundo.dir)  });
}

}

//////////////////////////////////// (  End  )

